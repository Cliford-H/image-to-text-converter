# Image to Text Converter (OCR)

## Problem Statement
Extracting text from images is essential for document digitization and automation. This project converts image content into readable text using OCR techniques.

## Objective
To build an application that accurately extracts text from images.

## Tech Stack
- Python
- OCR (Tesseract / EasyOCR)
- OpenCV
- Pillow

## Project Workflow
1. Input image
2. Image preprocessing
3. OCR text extraction
4. Output text

## How to Run
1. Install dependencies
   pip install -r requirements.txt
2. Run the application
   python app.py

## Disclaimer
This project is for educational purposes only.